class PlateState {
  final String plate;
  final bool isValid;

  PlateState({required this.plate, required this.isValid});
}